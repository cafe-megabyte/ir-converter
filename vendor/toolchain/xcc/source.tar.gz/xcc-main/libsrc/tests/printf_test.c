#include <stdio.h>

#include <inttypes.h>  // PRIdMAX, PRIuMAX, PRId64, PRIu64, PRIx64
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>  // intptr_t
#include <stdlib.h>
#include <string.h>

#ifndef __NO_FLONUM
#include <math.h>
#include <float.h>
#endif

#include "../../tests/xtest.h"

#define SSIZE  (64)
#define MARKER  (0xbd)

void expect_vsnprintf(const char *expected, int expected_len, const char *fmt, ...) {
  begin_test(expected);

  char out[SSIZE + 1];
  out[SSIZE] = MARKER;

  va_list ap;
  va_start(ap, fmt);
  int len = vsnprintf(out, SSIZE, fmt, ap);
  va_end(ap);
  int written = len < SSIZE - 1 ? len : SSIZE - 1;

  if (len != expected_len || memcmp(expected, out, written) != 0) {
    fail("actal [%s], len=%d/%d", out, len, expected_len);
  } else if ((unsigned char)out[SSIZE] != MARKER) {
    fail("marker broken");
  } else if (out[written] != '\0') {
    fail("not nul terminated, %d, [%s]\n", len, out);
  }
}

TEST(fmemopen) {
  static const char str[] = "abcdefghijklmnopqrstuvwxyz";
  char buf[32];
  FILE *fp;
  fp = fmemopen(buf, sizeof(buf), "w");
  if (EXPECT_NOT_NULL(fp)) {
    EXPECT_EQ(sizeof(str), fwrite(str, 1, sizeof(str), fp));
    EXPECT_EQ(sizeof(str), ftell(fp));
    fclose(fp);
  }

  fp = fmemopen((void*)str, sizeof(str), "r");
  if (EXPECT_NOT_NULL(fp)) {
    EXPECT_EQ(sizeof(str), fread(buf, 1, sizeof(buf), fp));
    EXPECT_EQ(sizeof(str), ftell(fp));
    fclose(fp);
    EXPECT_EQ(0, memcmp(buf, str, sizeof(str)));
  }

  EXPECT_NULL(fmemopen((void*)buf, 0, "r"));  // Failed opening size 0 for read.
  EXPECT_NULL(fmemopen((void*)buf, 0, "w"));  // Failed opening size 0 for write.
}

TEST(open_memstream) {
  char *ptr = NULL;
  size_t size = 0;
  FILE *fp = open_memstream(&ptr, &size);
  if (EXPECT_NOT_NULL(fp)) {
    EXPECT_EQ(12, fprintf(fp, "Hello world\n"));
    EXPECT_EQ(14, fprintf(fp, "Number: %d\n", 12345));
    fclose(fp);
    EXPECT_NOT_NULL(ptr);
    EXPECT_EQ(12 + 14, size);
    free(ptr);
  }
}

TEST(sprintf) {
  char buf[16];
  memset(buf, 0x7f, sizeof(buf));
  EXPECT_EQ(5, sprintf(buf, "%d", 12345));
  EXPECT_EQ('\0', buf[5]);
  EXPECT_EQ(0x7f, buf[6]);
}

TEST(vsnprintf) {
#define EXPECT(expected, fmt, ...)  expect_vsnprintf(expected, sizeof(expected)-1, fmt, __VA_ARGS__)
  EXPECT("Number:123", "Number:%d", 123);
  EXPECT("Negative:-456", "Negative:%d", -456);
  EXPECT("Flag:+789", "Flag:%+d", 789);
  EXPECT("FlagNeg:-987", "FlagNeg:%+d", -987);
  EXPECT("Padding:  654", "Padding:%5d", 654);
  EXPECT("ZeroPadding:00321", "ZeroPadding:%05d", 321);
  EXPECT("ZeroPaddingNeg:-000456", "ZeroPaddingNeg:%07d", -456);
  EXPECT("PaddingOver:12345678", "PaddingOver:%5d", 12345678);
  EXPECT("EndPadding:234  ", "EndPadding:%-5d", 234);
  EXPECT("Precision:0012345", "Precision:%3.7d", 12345);
  EXPECT("Hex:89ab", "Hex:%x", 0x89ab);
  EXPECT("Octal:755", "Octal:%o", 0755);
  if (sizeof(int) == 4) {
    EXPECT("Hex-:ffff7655", "Hex-:%x", -0x89ab);
    EXPECT("Unsigned:4294932053", "Unsigned:%u", -0x89ab);
  }
  if (sizeof(long) == 8) {
    EXPECT("ULong:18446744073709551615", "ULong:%lu", -1L);
  }
  if (sizeof(long long) == 8) {
    EXPECT("ULLong:18446744073709551615", "ULLong:%llu", -1LL);
    EXPECT("PRIdMAX:9223372036854775807", "PRIdMAX:%" PRIdMAX, INTMAX_MAX);
    EXPECT("PRIuMAX:18446744073709551615", "PRIuMAX:%" PRIuMAX, UINTMAX_MAX);
  }
  EXPECT("size_t:54321, ssize_t:-54321", "size_t:%zu, ssize_t:%zd", (size_t)54321, (ssize_t)-54321);
  EXPECT("size_t:0x54321", "size_t:0x%zx", (size_t)0x54321);
  EXPECT("PRId64:1311768467463790320", "PRId64:%" PRId64, (int64_t)0x123456789abcdef0);
  EXPECT("PRIu64:18364758544493064720", "PRIu64:%" PRIu64, (uint64_t)0xfedcba9876543210);
  EXPECT("int:0x123,d64:0x456", "int:0x%x,d64:0x%" PRIx64, 0x123, (int64_t)0x456);

  EXPECT("String:Foo.", "String:%s.", "Foo");
  EXPECT("BeginPadding:  Bar", "BeginPadding:%5s", "Bar");
  EXPECT("EndPadding:Baz  ", "EndPadding:%-5s", "Baz");
  EXPECT("SubstringRemain:   Fo", "SubstringRemain:%5.5s", "Fo");
  EXPECT("SubstringCut:FooBa", "SubstringCut:%5.5s", "FooBarBaz");
  EXPECT("NullString:(null)", "NullString:%s", NULL);

  EXPECT("Param:  Foo", "Param:%*s", 5, "Foo");
  EXPECT("Param2:FooBa", "Param2:%.*s", 5, "FooBarBaz");

  EXPECT("Character", "Char%ccter", 'a');
  EXPECT("Nul\0Inserted", "Nul%cInserted", '\0');
  EXPECT("%", "%%", 666);

  EXPECT("MoreThanBufferSize:12345678901234567890123456789012345678901234567890", "MoreThanBufferSize:%s", "12345678901234567890123456789012345678901234567890");

  EXPECT("Pointer:0x1234", "Pointer:%p", (void*)(intptr_t)0x1234);
  EXPECT("Pointer:  0x1234", "Pointer:%8p", (void*)(intptr_t)0x1234);
  EXPECT("NullPointer:0x0", "NullPointer:%p", NULL);

#ifndef __NO_FLONUM
  EXPECT("Float:1.234000", "Float:%f", 1.234);
  EXPECT("Float-:-1.234000", "Float-:%f", -1.234);
  EXPECT("Float+:+1.234000", "Float+:%+f", 1.234);
  EXPECT("FloatSub:1.23", "FloatSub:%.2f", 1.234);
  EXPECT("Float:0.000000", "Float:%f", 0.0);
  EXPECT("Float:-0.000000", "Float:%f", -0.0);
  EXPECT("inf:inf", "inf:%f", HUGE_VAL);
  EXPECT("nan:nan", "nan:%f", NAN);

  EXPECT("Scientific:0.999999", "Scientific:%g", 0.999999);
  EXPECT("Scientific:1", "Scientific:%g", 0.9999999);
  EXPECT("Scientific:-12.345", "Scientific:%g", -12.345);
  EXPECT("Scientific:0", "Scientific:%g", 0.0);
  EXPECT("Scientific:-0", "Scientific:%g", -0.0);
  EXPECT("Scientific:123400", "Scientific:%g", 1.234e5);
  EXPECT("Scientific:1.234e+06", "Scientific:%g", 1.234e6);
  EXPECT("Scientific:0.0001234", "Scientific:%g", 1.234e-4);
  EXPECT("Scientific:1.234e-05", "Scientific:%g", 1.234e-5);
  EXPECT("Scientific:-inf", "Scientific:%g", -HUGE_VAL);
  EXPECT("Scientific:nan", "Scientific:%g", NAN);

  EXPECT("DBL_MIN:2.22507e-308", "DBL_MIN:%g", DBL_MIN);
  EXPECT("DBL_MAX:1.79769e+308", "DBL_MAX:%g", DBL_MAX);
  EXPECT("FLT_MIN:1.17549e-38", "FLT_MIN:%g", FLT_MIN);
  EXPECT("FLT_MAX:3.40282e+38", "FLT_MAX:%g", FLT_MAX);

  EXPECT("Width:    3.14", "Width:%8.2f", 3.14159);
  EXPECT("Left:3.14    |", "Left:%-8.2f|", 3.14159);
  EXPECT("Zero:-0003.14", "Zero:%08.2f", -3.14159);
  EXPECT("Plus:+2.2", "Plus:%+.1f", 2.25);  // A true tie rounds to even
  EXPECT("Prec0:2", "Prec0:%.0f", 2.5);
  EXPECT("Prec0:4", "Prec0:%.0f", 3.5);
  EXPECT("Prec0:1024", "Prec0:%.0f", 1024.0);
  EXPECT("Alt:3.", "Alt:%#.0f", 3.0);
  EXPECT("Round: -0.1", "Round:%5.1f", -0.05);  // -0.05 is stored as slightly more than 0.05
  EXPECT("Round:0.1", "Round:%.1f", 0.15);  // 0.15 is stored as slightly less
  EXPECT("Round:0.12", "Round:%.2f", 0.125);  // An exact tie: to even
  EXPECT("Round:1.00", "Round:%.2f", 1.005);
  EXPECT("Exp:1.234568e+04", "Exp:%e", 12345.678);
  EXPECT("Exp:1.23E-04", "Exp:%.2E", 0.000123);
  EXPECT("Exp:  1.0e+100", "Exp:%10.1e", 1e100);
  EXPECT("Exp:1.000000e-310", "Exp:%e", 1e-310);  // Subnormal
  EXPECT("G:1e-310", "G:%g", 1e-310);
  EXPECT("G:1.23457E+08", "G:%G", 123456789.0);
  EXPECT("G:2.00000", "G:%#g", 2.0);
  EXPECT("Mixed:1.5e+00 7", "Mixed:%.1e %d", 1.5, 7);
#endif
#undef EXPECT
}

XTEST_MAIN();
